package ch.patrickfrei.myapp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Tab_2 extends Fragment {


    private Context mContext;
    private CustomArrayAdapter adapter;

    public Tab_2() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.tab_2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView lv = view.findViewById(R.id.tab2ListView);
        adapter = new CustomArrayAdapter(this.getActivity(), getTabGeneralList());
        lv.setAdapter(adapter);
        lv.setLayoutManager(new LinearLayoutManager(this.getActivity()));
    }

    private ArrayList<CustomDataStructure> getTabGeneralList() {
        CustomDataStructure item;
        ArrayList<CustomDataStructure> items = new ArrayList<>();

        for (int i=0;i<50;i++) {
            item = new CustomDataStructure("Tab 2 Item "+i, "Lorem ipsum dolor sit amet, consectetur adipiscing.");
            items.add(item);
        }

        return items;
    }
	
}
