package ch.patrickfrei.myapp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.os.LocaleListCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;

import java.util.ArrayList;
import java.util.Locale;

public class Tab_2 extends Fragment {


    private Context mContext;
    private CustomArrayAdapter adapter;

    public Tab_2() {
        // Required empty public constructor
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_action_arabic) {
            LocaleListCompat appLocale = LocaleListCompat.forLanguageTags("ar");
            AppCompatDelegate.setApplicationLocales(appLocale);
            return true;
        } else if (id == R.id.menu_action_english) {
            LocaleListCompat appLocale = LocaleListCompat.forLanguageTags("en");
            AppCompatDelegate.setApplicationLocales(appLocale);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext=context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.tab_2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView lv = view.findViewById(R.id.tab2ListView);
        adapter = new CustomArrayAdapter(this.getActivity(), new ArrayList<>());
        lv.setAdapter(adapter);
        lv.setLayoutManager(new LinearLayoutManager(this.getActivity()));
    }

    @Override
    public void onResume() {
        super.onResume();

        final android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ArrayList<CustomDataStructure> tab2list = getTab2List();
                adapter.setData(tab2list);
                adapter.notifyDataSetChanged();
            }
        }, 0);
    }

    private ArrayList<CustomDataStructure> getTab2List() {
        CustomDataStructure item;
        ArrayList<CustomDataStructure> items = new ArrayList<>();

        for (int i=0;i<50;i++) {
            item = new CustomDataStructure(getResources().getString(R.string.blindtext_2)+" "+i, getResources().getString(R.string.blindtext_0));
            items.add(item);
        }

        return items;
    }
	
}
