package ch.patrickfrei.myapp;

import android.app.Application;

import com.google.android.material.color.DynamicColors;

public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Support of Material Design M3 Dynamic Colors
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}