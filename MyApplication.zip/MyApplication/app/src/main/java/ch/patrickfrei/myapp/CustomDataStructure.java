package ch.patrickfrei.myapp;

public class CustomDataStructure {

    String title;
    String content;
    int indexInSection;
    int sectionCount;

    public CustomDataStructure(String title, String content, int indexInSection, int sectionCount) {
        this.title = title;
        this.content = content;
        this.indexInSection = indexInSection;
        this.sectionCount = sectionCount;
    }

}
