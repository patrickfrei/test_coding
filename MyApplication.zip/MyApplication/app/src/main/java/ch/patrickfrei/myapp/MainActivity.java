package ch.patrickfrei.myapp;

import android.os.Bundle;
import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        initialize();
    }

    private void initialize() {
        final int[] tabIcons = {
                R.drawable.ic_info_outline_white_24dp,
                R.drawable.ic_info_outline_white_24dp
        };

        final String[] tabText = {
                "Alpha",
                "Beta"
        };

        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mViewPager = findViewById(R.id.container);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle());
        adapter.addFragment(new Tab_1());
        adapter.addFragment(new Tab_2());
        mViewPager.setOffscreenPageLimit(1);
        mViewPager.setAdapter(adapter);

        TabLayout tabLayout;
        tabLayout = findViewById(R.id.tabs);

        new TabLayoutMediator(tabLayout, mViewPager,
                (tab, position) -> {
                    tab.setText(tabText[position]);
                    tab.setIcon(tabIcons[position]);
                }).attach();

        // Set dynamic status bar color in Material M3 design
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            AppBarLayout appBarLayout = findViewById(R.id.appbar);
            appBarLayout.setStatusBarForeground(MaterialShapeDrawable.createWithElevationOverlay(MainActivity.this));
        }

        // Set insets to match edge-to-edge layout
        View view = findViewById(R.id.main_content);
        ViewCompat.setOnApplyWindowInsetsListener(view, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            /* R.id.container */
            mViewPager.setPadding(
                    mViewPager.getPaddingLeft(),
                    mViewPager.getPaddingTop(),
                    mViewPager.getPaddingRight(),
                    insets.bottom
            );

            return windowInsets;
        });
    }

    static class ViewPagerAdapter extends FragmentStateAdapter {
        private ArrayList<Fragment> arrayList = new ArrayList<>();

        public ViewPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
            super(fragmentManager, lifecycle);
        }

        public void addFragment(Fragment fragment) {
            arrayList.add(fragment);
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return arrayList.get(position);
        }
    }

}
