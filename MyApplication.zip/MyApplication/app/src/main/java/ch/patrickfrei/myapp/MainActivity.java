package ch.patrickfrei.myapp;

import android.os.Bundle;
import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;

import android.util.Log;
import android.view.View;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        initialize();
    }

    private void initialize() {
        final int[] tabIcons = {
                R.drawable.ic_info_outline_white_24dp,
                R.drawable.ic_airport_shuttle_outline_white_24dp
        };

        final String[] tabText = {
                "Alpha",
                "Beta"
        };

        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mViewPager = findViewById(R.id.container);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle());
        adapter.addFragment(new Tab_1());
        adapter.addFragment(new Tab_2());
        mViewPager.setOffscreenPageLimit(1);
        mViewPager.setAdapter(adapter);

        TabLayout tabLayout;
        tabLayout = findViewById(R.id.tabs);

        /* Variant 1 setLiftOnScrollTargetViewId */
        tabLayout.addOnTabSelectedListener(
                new TabLayout.OnTabSelectedListener() {
                    @Override
                    public void onTabSelected(TabLayout.Tab tab) {
                        if (android.os.Build.VERSION.SDK_INT >= 29) {
                            int recyclerviewId;
                            switch (tab.getPosition()) {
                                case 0:
                                    recyclerviewId = R.id.tab1ListView;
                                    break;
                                case 1:
                                    recyclerviewId = R.id.tab2ListView;
                                    break;
                                default:
                                    recyclerviewId = R.id.tab1ListView;
                            }
                            AppBarLayout appBarLayout = findViewById(R.id.appbar);
                            appBarLayout.setLiftOnScrollTargetViewId(recyclerviewId);
                            appBarLayout.forceLayout();
                        }
                    }
                    @Override
                    public void onTabUnselected(TabLayout.Tab tab) {
                    }
                    @Override
                    public void onTabReselected(TabLayout.Tab tab) {
                        // no-op
                    }
                }
        );

        /* Variant 2 setLiftOnScrollTargetViewId */
/*        mViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                // no-op
            }
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    int recyclerviewId;
                    switch (position) {
                        case 0: recyclerviewId = R.id.tab1ListView; break;
                        case 1: recyclerviewId = R.id.tab2ListView; break;
                        default: recyclerviewId = R.id.tab1ListView;
                    }
                    AppBarLayout appBarLayout = findViewById(R.id.appbar);
                    appBarLayout.setLiftOnScrollTargetViewId(recyclerviewId);
                    appBarLayout.forceLayout();
                }
            }
            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
                // no-op
            }
        });*/

        new TabLayoutMediator(tabLayout, mViewPager,
                (tab, position) -> {
                    tab.setText(tabText[position]);
                    tab.setIcon(tabIcons[position]);
                }).attach();

        // Set dynamic status bar color in Material M3 design
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            AppBarLayout appBarLayout = findViewById(R.id.appbar);
            appBarLayout.setStatusBarForeground(MaterialShapeDrawable.createWithElevationOverlay(MainActivity.this));
        }

        // Set insets to match edge-to-edge layout
        View view = findViewById(R.id.main_content);
        ViewCompat.setOnApplyWindowInsetsListener(view, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            /* R.id.container */
            mViewPager.setPadding(
                    mViewPager.getPaddingLeft(),
                    mViewPager.getPaddingTop(),
                    mViewPager.getPaddingRight(),
                    insets.bottom
            );

            return windowInsets;
        });
    }

    static class ViewPagerAdapter extends FragmentStateAdapter {
        private ArrayList<Fragment> arrayList = new ArrayList<>();

        public ViewPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
            super(fragmentManager, lifecycle);
        }

        public void addFragment(Fragment fragment) {
            arrayList.add(fragment);
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return arrayList.get(position);
        }
    }

}
