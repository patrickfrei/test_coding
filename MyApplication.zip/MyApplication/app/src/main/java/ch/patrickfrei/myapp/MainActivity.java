package ch.patrickfrei.myapp;

import android.os.Bundle;
import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.adapter.FragmentViewHolder;
import androidx.viewpager2.widget.ViewPager2;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;

import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 mViewPager;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        initialize();
    }

    private void initialize() {
        final int[] tabIcons = {
                R.drawable.ic_info_outline_white_24dp,
                R.drawable.ic_airport_shuttle_outline_white_24dp
        };

        final String[] tabText = {
                getResources().getString(R.string.tab_1),
                getResources().getString(R.string.tab_2)
        };

        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mViewPager = findViewById(R.id.container);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), getLifecycle());
        adapter.addFragment(new Tab_1());
        adapter.addFragment(new Tab_2());
        mViewPager.setOffscreenPageLimit(1);
        mViewPager.setAdapter(adapter);

        TabLayout tabLayout;
        tabLayout = findViewById(R.id.tabs);

        tabLayout.addOnTabSelectedListener(
                new TabLayout.OnTabSelectedListener() {
                    @Override
                    public void onTabSelected(TabLayout.Tab tab) {
                        int recyclerviewId;
                        switch (tab.getPosition()) {
                            case 0:
                                recyclerviewId = R.id.tab1ListView;
                                break;
                            case 1:
                                recyclerviewId = R.id.tab2ListView;
                                break;
                            default:
                                recyclerviewId = R.id.tab1ListView;
                        }
                        AppBarLayout appBarLayout = findViewById(R.id.appbar);
                        appBarLayout.setLiftOnScrollTargetViewId(recyclerviewId);
                    }
                    @Override
                    public void onTabUnselected(TabLayout.Tab tab) {
                        // no-op
                    }
                    @Override
                    public void onTabReselected(TabLayout.Tab tab) {
                        // no-op
                    }
                }
        );

        new TabLayoutMediator(tabLayout, mViewPager,
                (tab, position) -> {
                    tab.setText(tabText[position]);
                    tab.setIcon(tabIcons[position]);
                }).attach();

        // Set dynamic status bar color in Material M3 design
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            AppBarLayout appBarLayout = findViewById(R.id.appbar);
            appBarLayout.setStatusBarForeground(MaterialShapeDrawable.createWithElevationOverlay(MainActivity.this));
        }

        if (android.os.Build.VERSION.SDK_INT <24) {
            AppBarLayout.LayoutParams appBarLayoutParams = (AppBarLayout.LayoutParams) toolbar.getLayoutParams();
            appBarLayoutParams.setScrollEffect(null);
        }

        // Set insets to match edge-to-edge layout
        View view = findViewById(R.id.main_content);
        ViewCompat.setOnApplyWindowInsetsListener(view, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());

            /* R.id.main_content / handle navigation bar overlay in landscape mode
               left & right are 0 in portrait mode but set to the height of the
               navigation bar landscape mode */
            view.setPadding(
                    insets.left,
                    view.getPaddingTop(), // 0
                    insets.right,
                    view.getPaddingBottom() // 0
            );

            /* R.id.container / handle Recyclerview navigation bar overlay*/
            mViewPager.setPadding(
                    mViewPager.getPaddingLeft(), // 0
                    mViewPager.getPaddingTop(), // 0
                    mViewPager.getPaddingRight(), // 0
                    insets.bottom
            );

            return windowInsets;
        });

        /* Workaround for clipping in Auto-generated elements
            ViewPager2
              RecyclerViewImpl  <=== see code below
                FrameLayout
                  ConstraintLayout
                   RecyclerView */
        try {
            ViewGroup vg = (ViewGroup) mViewPager.getChildAt(0);
            vg.setClipChildren(false);
            vg.setClipToPadding(false);
        } catch (Exception e) {
            Log.d("Exception", e.toString());
        }
    }

    static class ViewPagerAdapter extends FragmentStateAdapter {
        private final ArrayList<Fragment> arrayList = new ArrayList<>();

        public ViewPagerAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
            super(fragmentManager, lifecycle);
        }

        public void addFragment(Fragment fragment) {
            arrayList.add(fragment);
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return arrayList.get(position);
        }

        @Override
        public void onBindViewHolder(@NonNull FragmentViewHolder holder, int position, @NonNull List<Object> payloads) {
            /* Workaround for clipping in auto-generated elements
            ViewPager2
              RecyclerViewImpl
                FrameLayout  <=== see code below
                  ConstraintLayout
                   RecyclerView */
            try {
                ViewGroup vg = (ViewGroup) holder.itemView;
                vg.setClipChildren(false);
                vg.setClipToPadding(false);
            } catch (Exception e) {
                Log.d("Exception", e.toString());
            }
            super.onBindViewHolder(holder, position, payloads);
        }
    }

}
