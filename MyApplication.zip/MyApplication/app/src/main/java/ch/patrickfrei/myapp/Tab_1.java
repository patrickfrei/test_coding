package ch.patrickfrei.myapp;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class Tab_1 extends Fragment {

    private CustomArrayAdapter adapter;

    public Tab_1() {
        // Required empty public constructor
    }

    private void setupMenu() {
        MenuProvider menuProvider = new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                /*if (!menu.hasVisibleItems()) {  // only inflate if no items
                    menuInflater.inflate(R.menu.menu_main, menu);
                }*/
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                // Activate menu item for this fragment only
                int id = menuItem.getItemId();
                if (id == R.id.menu_action_arabic) {
                    LocaleListCompat appLocale = LocaleListCompat.forLanguageTags("ar");
                    AppCompatDelegate.setApplicationLocales(appLocale);
                    return true;
                } else if (id == R.id.menu_action_english) {
                    LocaleListCompat appLocale = LocaleListCompat.forLanguageTags("en");
                    AppCompatDelegate.setApplicationLocales(appLocale);
                    return true;
                }
                return false;
            }
        };

        requireActivity().addMenuProvider(menuProvider, getViewLifecycleOwner(), Lifecycle.State.RESUMED);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.tab_1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setupMenu();
        RecyclerView lv = view.findViewById(R.id.tab1ListView);
        adapter = new CustomArrayAdapter(this.getActivity(), new ArrayList<>());
        lv.setAdapter(adapter);
        lv.setLayoutManager(new LinearLayoutManager(this.getActivity()));
    }

    @Override
    public void onResume() {
        super.onResume();

        final android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ArrayList<CustomDataStructure> tab1list = getTab1List();
                adapter.setData(tab1list);
                adapter.notifyDataSetChanged();
            }
        }, 0);
    }

    private ArrayList<CustomDataStructure> getTab1List() {
        CustomDataStructure item;
        ArrayList<CustomDataStructure> items = new ArrayList<>();

        for (int i=0;i<50;i++) {
            item = new CustomDataStructure(getResources().getString(R.string.blindtext_1)+" "+i, getResources().getString(R.string.blindtext_0),i,50);
            items.add(item);
        }

        return items;
    }

}
