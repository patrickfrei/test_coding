package ch.patrickfrei.myapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import com.google.android.material.listitem.ListItemViewHolder;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class CustomArrayAdapter extends Adapter<CustomArrayAdapter.CustomItemViewHolder> {

    ArrayList<CustomDataStructure> listItems;
    LayoutInflater inflater;

    public static class CustomItemViewHolder extends ListItemViewHolder {
        private final MaterialTextView titleTxt;
        private final MaterialTextView contentTxt;

        public CustomItemViewHolder(@NonNull View view) {
            super(view);
            titleTxt = view.findViewById(R.id.titleTxt);
            contentTxt = view.findViewById(R.id.contentTxt);
        }

        public void bind(@NonNull CustomDataStructure data) {
            super.bind();
            titleTxt.setText(data.title);
            contentTxt.setText(data.content);
        }

    }

    public CustomArrayAdapter(Context mContext, ArrayList<CustomDataStructure> listItems) {
        setHasStableIds(true);
        this.listItems = listItems;
        this.inflater = LayoutInflater.from(mContext);
    }

    public void setData(ArrayList<CustomDataStructure> list){
        listItems = list;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return listItems == null ? 0 : listItems.size();
    }

    @NonNull
    public CustomDataStructure getItemAt(int i) {
        return listItems.get(i);
    }

    @NonNull
    @Override
    public CustomItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_view, parent, false);
        return new CustomItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomItemViewHolder viewHolder, int position) {
        CustomDataStructure data = getItemAt(position);
        viewHolder.bind(data);
    }

}
