package ch.patrickfrei.myapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;

public class CustomArrayAdapter extends RecyclerView.Adapter<CustomArrayAdapter.ViewHolder> {

    private final Context mContext;
    ArrayList<CustomDataStructure> listItems;
    LayoutInflater inflater;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final MaterialTextView titleTxt;
        private final MaterialTextView contentTxt;

        public ViewHolder(View view) {
            super(view);
            titleTxt = (MaterialTextView) view.findViewById(R.id.titleTxt);
            contentTxt = (MaterialTextView) view.findViewById(R.id.contentTxt);
        }

        public MaterialTextView getTitleTxtView() {
            return titleTxt;
        }
        public MaterialTextView getContentTxtView() {
            return contentTxt;
        }
    }

    public CustomArrayAdapter(Context mContext, ArrayList<CustomDataStructure> listItems) {
        setHasStableIds(true);
        this.mContext = mContext;
        this.listItems = listItems;
        this.inflater = LayoutInflater.from(mContext);
    }

    public void setData(ArrayList<CustomDataStructure> list){
        listItems = list;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return listItems == null ? 0 : listItems.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final CustomDataStructure data = listItems.get(position);
        holder.getTitleTxtView().setText(data.getTitle());
        holder.getContentTxtView().setText(data.getContent());

        // Alternating color for list rows
        /*if (position %2 == 1) {
            holder.getTitleTxtView().setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorListViewEven));
            holder.getContentTxtView().setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorListViewEven));
        } else {
            holder.getTitleTxtView().setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorListViewOdd));
            holder.getContentTxtView().setBackgroundColor(ContextCompat.getColor(mContext, R.color.colorListViewOdd));
        }*/

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, data.getTitle() + "\n" + data.getContent(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
